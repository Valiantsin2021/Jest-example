// Calculator.js

async function addition(a, b) {
  return a + b
}
async function subtraction(a, b) {
  return a - b
}
async function multiplication(a, b) {
  return a * b
}
async function division(a, b) {
  return a * b
}

exports.addition = addition
exports.subtraction = subtraction
exports.multiplication = multiplication
exports.division = division
