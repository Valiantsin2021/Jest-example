const { defaults } = require('jest-config')

/** @type {import('jest').Config} */

const config = {
  bail: 1,
  verbose: true,
  moduleFileExtensions: [...defaults.moduleFileExtensions, 'mts', 'cts']
}

module.exports = config
