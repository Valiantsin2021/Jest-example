const calculator = require('../calculator.js')
/** @type {import('jest')} jest */

//Mock the imported module
jest.mock('../calculator.js') // Here mention the path to the file

// While mocking it is not required to give exact value
test('Mocking of addition function', async () => {
  calculator.addition.mockReturnValueOnce(5)
  let res = calculator.addition(2, 10)
  expect(res).toBe(5)
})

test('Mocking of subtraction function', async () => {
  calculator.subtraction.mockReturnValueOnce(5)
  let res = calculator.subtraction(2, 10)
  expect(res).toBe(5)
})

test('Mocking of multiplication function', async () => {
  calculator.multiplication.mockReturnValueOnce(5)
  let res = calculator.multiplication(2, 10)
  expect(res).toBe(5)
})

//Mock the funtion the we want to use.
calculator.addition = jest.fn() // Mocking of addition function
calculator.subtraction = jest.fn() // Mocking of subtraction function.

test('Mocking of addition function', async () => {
  calculator.addition.mockReturnValueOnce(5)
  let res = calculator.addition(2, 10)
  expect(res).toBe(5)
})

test('Mocking of division function', async () => {
  calculator.division.mockReturnValueOnce(5)
  let res = calculator.division(2, 10)
  expect(res).toBe(5)
})

//Mock the funciton that we want.
const addSpy = jest.spyOn(calculator, 'addition') // Mocking of addition function
const subSpy = jest.spyOn(calculator, 'subtraction') // Mocking of subtraction function

test('Mocking of addition function', async () => {
  addSpy.mockReturnValueOnce(12)
  let res = calculator.addition(2, 10)
  expect(res).toBe(12)
})

test('Mocking of subtraction function', async () => {
  subSpy.mockReturnValueOnce(8)
  let res = calculator.subtraction(2, 10)
  expect(res).toBe(8)
})
